/*
 * file: Quadratic.java
 * author: Miguel Solis
 * created: 2.14.19
 * desc: This program implements quadratic formula
 */
package test3;

import java.util.Scanner;

public class week3 {
	public static void main(String[] args) {
		System.out.print("\t\tWelcome to Quadratic 3000");
		System.out.print("This program implements quadratic formula");
		
		 Scanner scnr = new Scanner(System.in);
		 
		 double root1, root2;
		 double a, b, c;
		 double discr; 
		 
		 System.out.println("Enter value of a:");
		 a = input.nextDouble();
		 System.out.println("Enter value of b");
		 b = input.nextDouble();
		 System.out.println("Enter vaulue of c");
		 c = input.Double();
		 
		 discr = b*b - 4*a*c;
		 root1= (-b * Math.sqrt(discr))/2*a;
		 root2= (-b - Math.sqrt(discr))/2*a;
		

	}

}
